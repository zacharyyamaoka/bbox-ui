#!/usr/bin/env node
// scripts/flake/repeat.mjs — G-FLAKE's acceptance: run the browser suites N
// times under load and count, per named flaky file, how many runs it passed.
//
//   node scripts/flake/repeat.mjs                       # the gate: 10 full runs of each package, 12 CPU burners
//   node scripts/flake/repeat.mjs --mode order          # the deterministic cross-file bleed repros (seconds)
//   node scripts/flake/repeat.mjs --mode flaky --only FLAKE-SB-DevPanel,FLAKE-SB-AppMenu --repeat 20
//   node scripts/flake/repeat.mjs --mode alone --only FLAKE-SB-DevPanel
//
// Flags
//   --package a,b    storybook-basics | studio | glyph-picker (default: manifest.defaultPackages)
//   --repeat N       samples per entry (default 10 — lanes.json G-FLAKE acceptance)
//   --mode M         full  (default) — every iteration runs the WHOLE package suite, so each named
//                           file runs among every other file, concurrently: "under a concurrent
//                           full-suite load". This is the gate.
//                    flaky — every iteration runs only the package's named files, together
//                    alone — every iteration runs each named file by itself
//                    order — every iteration runs each manifest.orderRepros entry (fixed file order)
//   --load K         K extra busy-loop processes for the whole session (default 12). WHY: the
//                    flakes were measured at load 35-78 with peer sessions running, and a gate
//                    that only goes red when the box happens to be busy is not a gate. Pass 0 to
//                    measure whatever load the box has.
//   --only ids       restrict to these entry ids (comma-separated)
//   --out DIR        where logs + summary go (default $TMPDIR/bbox-flake/<timestamp>)
//   --run-timeout-min T   per vitest run (default 30); our own child is stopped past it
//   --port-wait-min W     how long to wait for another session's run to release the browser port (default 180)
//
// Exit 0 = every gated entry passed every sample and every static check holds.
// Exit 1 = at least one did not (the table says which, in which iteration, why).
// Exit 2 = the harness could not get results (port never freed, vitest never started).
//
// Browser runs share vitest's default port (manifest.browserPort, 63315) with
// every worktree on this machine. The harness NEVER stops another process: it
// waits until nothing listens on the port, and if it loses the race anyway
// (the run reports the port in use and writes no results) it waits and
// retries that iteration without counting it.

import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { failedFiles, fileOrder, gatePasses, judgeEntry, reportHasResults, summarise } from "./tally.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "../..");
const manifest = JSON.parse(readFileSync(path.join(here, "manifest.json"), "utf8"));

// ---------------------------------------------------------------- arguments
function parseArgs(argv) {
  const options = { repeat: 10, mode: "full", load: 12, only: null, packages: null, out: null, runTimeoutMin: 30, portWaitMin: 180 };
  for (let index = 0; index < argv.length; index++) {
    const [flag, inline] = argv[index].split("=", 2);
    const value = () => (inline !== undefined ? inline : argv[++index]);
    switch (flag) {
      case "--repeat": options.repeat = Number(value()); break;
      case "--mode": options.mode = value(); break;
      case "--load": options.load = Number(value()); break;
      case "--only": options.only = value().split(",").map((id) => id.trim()).filter(Boolean); break;
      case "--package": options.packages = value().split(",").map((name) => name.trim()).filter(Boolean); break;
      case "--out": options.out = path.resolve(value()); break;
      case "--run-timeout-min": options.runTimeoutMin = Number(value()); break;
      case "--port-wait-min": options.portWaitMin = Number(value()); break;
      case "--help": case "-h": console.log(readFileSync(fileURLToPath(import.meta.url), "utf8").split("\n").slice(1, 32).join("\n")); process.exit(0);
      default: throw new Error(`unknown flag ${argv[index]}`);
    }
  }
  if (!["full", "flaky", "alone", "order"].includes(options.mode)) throw new Error(`--mode must be full | flaky | alone | order, got ${options.mode}`);
  if (!(options.repeat >= 1)) throw new Error("--repeat must be >= 1");
  return options;
}

const options = parseArgs(process.argv.slice(2));
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const outDir = options.out ?? path.join(os.tmpdir(), "bbox-flake", stamp);
mkdirSync(outDir, { recursive: true });
const progressLog = path.join(outDir, "progress.log");

function say(line) {
  const text = `[${new Date().toISOString().slice(11, 19)}] ${line}`;
  console.log(text);
  appendFileSync(progressLog, `${text}\n`);
}

// ---------------------------------------------------------------- selection
let entries = manifest.entries;
if (options.only) {
  const unknown = options.only.filter((id) => !entries.some((entry) => entry.id === id));
  if (unknown.length) throw new Error(`unknown entry id(s): ${unknown.join(", ")}`);
  entries = entries.filter((entry) => options.only.includes(entry.id));
}
const packageNames = options.packages ?? (options.only ? [...new Set(entries.map((entry) => entry.package))] : manifest.defaultPackages);
for (const name of packageNames) if (!manifest.packages[name]) throw new Error(`unknown package ${name}`);
entries = entries.filter((entry) => packageNames.includes(entry.package));

// ---------------------------------------------------------------- the machine
function loadAverage() {
  try {
    return Number(readFileSync("/proc/loadavg", "utf8").split(" ")[0]);
  } catch {
    return os.loadavg()[0];
  }
}

/** Is anything LISTENing on `port` (IPv4 or IPv6)? Read from /proc so the probe never binds the port itself. */
function portInUse(port) {
  const hex = port.toString(16).toUpperCase().padStart(4, "0");
  for (const table of ["/proc/net/tcp", "/proc/net/tcp6"]) {
    let text = "";
    try {
      text = readFileSync(table, "utf8");
    } catch {
      continue;
    }
    for (const line of text.split("\n").slice(1)) {
      const columns = line.trim().split(/\s+/);
      if (columns.length < 4) continue;
      const localPort = columns[1].split(":").pop();
      if (localPort === hex && columns[3] === "0A") return true;
    }
  }
  return false;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitForPort(port) {
  const deadline = Date.now() + options.portWaitMin * 60_000;
  let announced = 0;
  for (;;) {
    if (!portInUse(port)) {
      // Debounce: a peer between two of its own runs frees the port for a moment.
      await sleep(3000);
      if (!portInUse(port)) return;
    }
    if (Date.now() > deadline) throw new Error(`port ${port} still in use after ${options.portWaitMin} min — another session's run; never killed`);
    if (Date.now() - announced > 60_000) {
      say(`  port ${port} is in use by another run — waiting (never killing it)`);
      announced = Date.now();
    }
    await sleep(5000);
  }
}

// The load: our own busy-loop children, stopped when we exit.
const burners = [];
function startBurners(count) {
  for (let index = 0; index < count; index++) {
    const child = spawn(process.execPath, ["-e", "for(;;){}"], { stdio: "ignore" });
    burners.push(child);
  }
}
function stopBurners() {
  for (const child of burners) {
    try {
      child.kill("SIGKILL");
    } catch {
      /* already gone */
    }
  }
  burners.length = 0;
}
for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"]) {
  process.on(signal, () => {
    stopBurners();
    process.exit(130);
  });
}
process.on("exit", stopBurners);

// ---------------------------------------------------------------- one vitest run
function runVitest(pkg, label, files, extraArgs) {
  const packageDir = path.join(repoRoot, pkg.dir);
  const jsonPath = path.join(outDir, `${label}.json`);
  const logPath = path.join(outDir, `${label}.log`);
  const args = ["exec", "vitest", "run", ...files, ...extraArgs, "--reporter=default", "--reporter=json", `--outputFile.json=${jsonPath}`];
  const started = Date.now();
  const loadBefore = loadAverage();
  return new Promise((resolve) => {
    writeFileSync(logPath, `$ (cd ${packageDir} && pnpm ${args.join(" ")})\n`);
    try {
      writeFileSync(jsonPath, "");
    } catch {
      /* fresh */
    }
    const child = spawn("pnpm", args, {
      cwd: packageDir,
      env: { ...process.env, NO_COLOR: "1", FORCE_COLOR: "0" },
      stdio: ["ignore", "pipe", "pipe"],
      detached: true,
    });
    let output = "";
    const collect = (chunk) => {
      const text = chunk.toString();
      output += text;
      appendFileSync(logPath, text);
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);
    const timer = setTimeout(() => {
      appendFileSync(logPath, `\n[repeat.mjs] run exceeded ${options.runTimeoutMin} min — stopping OUR OWN vitest (pgid ${child.pid})\n`);
      try {
        process.kill(-child.pid, "SIGTERM");
      } catch {
        /* gone */
      }
    }, options.runTimeoutMin * 60_000);
    child.on("close", (code) => {
      clearTimeout(timer);
      let report = null;
      try {
        const text = readFileSync(jsonPath, "utf8");
        report = text.trim() ? JSON.parse(text) : null;
      } catch {
        report = null;
      }
      resolve({
        code: code ?? -1,
        report,
        output,
        durationS: Math.round((Date.now() - started) / 100) / 10,
        loadBefore,
        loadAfter: loadAverage(),
        logPath,
        portRace: /already in use|EADDRINUSE/i.test(output),
      });
    });
  });
}

async function runWithRetries(pkg, label, files, extraArgs) {
  for (let attempt = 1; attempt <= 6; attempt++) {
    if (pkg.browser) await waitForPort(manifest.browserPort);
    const result = await runVitest(pkg, attempt === 1 ? label : `${label}-retry${attempt}`, files, extraArgs);
    if (reportHasResults(result.report)) return { ...result, attempts: attempt };
    say(`  ${label}: no results (exit ${result.code}${result.portRace ? ", browser port taken" : ""}) — ${result.logPath}; retrying`);
    await sleep(15_000);
  }
  return null;
}

// ---------------------------------------------------------------- static checks
function staticChecks() {
  const results = [];
  for (const check of manifest.staticChecks ?? []) {
    if (options.only && !options.only.includes(check.entry)) continue;
    const entry = manifest.entries.find((candidate) => candidate.id === check.entry);
    if (entry && !packageNames.includes(entry.package)) continue;
    const file = path.join(repoRoot, check.file);
    let status = "fail";
    let detail = "";
    if (!existsSync(file)) {
      detail = `${check.file} does not exist`;
    } else {
      const text = readFileSync(file, "utf8");
      const start = text.indexOf(check.function);
      if (start < 0) {
        detail = `${check.function} not found in ${check.file}`;
      } else {
        // The function body: from its signature to the first line that is a bare "}".
        const end = text.indexOf("\n}\n", start);
        const body = text.slice(start, end < 0 ? undefined : end + 2);
        if (new RegExp(check.mustMatch).test(body)) status = "pass";
        else detail = `${check.function.replace("(", "")} never mentions ${check.mustMatch}`;
      }
    }
    results.push({ id: check.id, entry: check.entry, status, detail, why: check.why });
  }
  return results;
}

// ---------------------------------------------------------------- the session
function planFor(packageName) {
  const mine = entries.filter((entry) => entry.package === packageName);
  if (options.mode === "full") return [{ label: "full", files: [], args: [], entries: mine }];
  if (options.mode === "flaky") return [{ label: "flaky", files: [...new Set(mine.map((entry) => entry.file))], args: [], entries: mine }];
  if (options.mode === "alone") {
    const byFile = new Map();
    for (const entry of mine) byFile.set(entry.file, [...(byFile.get(entry.file) ?? []), entry]);
    return [...byFile].map(([file, group]) => ({ label: `alone-${path.basename(file).replace(/\W+/g, "_")}`, files: [file], args: [], entries: group }));
  }
  // order
  return (manifest.orderRepros ?? [])
    .filter((repro) => repro.package === packageName && mine.some((entry) => entry.id === repro.entry))
    .map((repro) => ({ label: repro.id, files: repro.files, args: repro.args ?? [], ordered: true, entries: mine.filter((entry) => entry.id === repro.entry) }));
}

function markdownSummary(totals, statics, runsByPackage, gate, finished) {
  const lines = [];
  lines.push(`# Flake repeat — ${options.mode} mode, ${options.repeat} runs, --load ${options.load}${finished ? "" : " (IN PROGRESS)"}`);
  lines.push("");
  lines.push(`- started ${stamp}; host ${os.hostname()}, ${os.cpus().length} CPUs; tree ${repoRoot}`);
  lines.push(`- command: \`node scripts/flake/repeat.mjs ${process.argv.slice(2).join(" ")}\``);
  lines.push(`- verdict: **${gate ? "PASS" : "FAIL"}** — ${gate ? "every gated entry passed every sample" : "at least one gated entry is below " + options.repeat + "/" + options.repeat + " (or a static check failed)"}`);
  lines.push("");
  for (const [packageName, runs] of Object.entries(runsByPackage)) {
    lines.push(`## ${packageName} — ${runs.length} run(s)`);
    lines.push("");
    lines.push("| run | load before → after | seconds | exit | files failed (any, named or not) |");
    lines.push("|---|---|---|---|---|");
    for (const run of runs) {
      lines.push(`| ${run.label} | ${run.loadBefore} → ${run.loadAfter} | ${run.durationS} | ${run.code} | ${run.failedFiles.map((failed) => `${failed.file}${failed.failed.length ? ` (${failed.failed.length})` : ""}`).join(", ") || "—"} |`);
    }
    lines.push("");
  }
  lines.push("## Per entry");
  lines.push("");
  lines.push("| id | file | gated | passed | failures (run: status — first line) |");
  lines.push("|---|---|---|---|---|");
  for (const total of totals) {
    const failures = total.failures.map((failure) => `#${failure.iteration}: ${failure.status} — ${failure.detail.replace(/\|/g, "\\|")}`).join("<br>") || "—";
    lines.push(`| ${total.id} | \`${total.file}\`${total.tests.length ? ` › ${total.tests.join(" / ")}` : ""} | ${total.followUp ? "no (follow-up)" : "yes"} | ${total.passes}/${total.samples} | ${failures} |`);
  }
  if (statics.length) {
    lines.push("");
    lines.push("## Static checks");
    lines.push("");
    for (const check of statics) lines.push(`- ${check.id} (${check.entry}): **${check.status.toUpperCase()}**${check.detail ? ` — ${check.detail}` : ""}`);
  }
  lines.push("");
  return lines.join("\n");
}

async function main() {
  say(`G-FLAKE repeat: mode ${options.mode}, ${options.repeat} runs, packages ${packageNames.join(", ")}, ${entries.length} entries, --load ${options.load}, out ${outDir}`);
  const statics = staticChecks();
  for (const check of statics) say(`static ${check.id}: ${check.status}${check.detail ? ` — ${check.detail}` : ""}`);

  if (options.load > 0) startBurners(options.load);
  const runsByPackage = {};
  const verdictRuns = [];
  let infraFailure = false;
  const plans = Object.fromEntries(packageNames.map((packageName) => [packageName, planFor(packageName)]));
  // Only entries some step actually samples are judged — in `order` mode that
  // is just the entries with a repro, never a 0/0 counted as a failure.
  const planned = entries.filter((entry) => Object.values(plans).some((plan) => plan.some((step) => step.entries.includes(entry))));

  const writeSummaries = (finished) => {
    const totals = summarise(planned, verdictRuns);
    const gate = !infraFailure && gatePasses(totals, options.repeat) && statics.every((check) => check.status === "pass");
    writeFileSync(path.join(outDir, "summary.json"), JSON.stringify({ options, stamp, repoRoot, finished, gate, statics, totals, runs: runsByPackage }, null, 2));
    writeFileSync(path.join(outDir, "summary.md"), markdownSummary(totals, statics, runsByPackage, gate, finished));
    return { totals, gate };
  };

  for (const packageName of packageNames) {
    const pkg = manifest.packages[packageName];
    const plan = plans[packageName];
    runsByPackage[packageName] = [];
    if (plan.length === 0) {
      say(`${packageName}: nothing to run in ${options.mode} mode`);
      continue;
    }
    for (let iteration = 1; iteration <= options.repeat; iteration++) {
      for (const step of plan) {
        const label = `${packageName}-${step.label}-${String(iteration).padStart(2, "0")}`;
        say(`${label}: starting (load ${loadAverage()})`);
        const result = await runWithRetries(pkg, label, step.files, step.args);
        if (!result) {
          infraFailure = true;
          say(`${label}: NO RESULTS after 6 attempts — harness failure, see ${outDir}`);
          continue;
        }
        const packageDir = path.join(repoRoot, pkg.dir);
        if (step.ordered) {
          // An order repro only means something if the files really ran in the
          // listed order; a run that did not is invalid, never a green sample.
          const ran = fileOrder(result.report, packageDir);
          if (ran.join(" ") !== step.files.join(" ")) {
            infraFailure = true;
            say(`${label}: files ran as [${ran.join(", ")}], not [${step.files.join(", ")}] — sample INVALID; pick another --sequence.seed in manifest.orderRepros`);
            continue;
          }
        }
        const verdicts = {};
        for (const entry of step.entries) {
          let verdict = judgeEntry(result.report, packageDir, entry);
          if (entry.failOnNonzeroExit && verdict.status === "pass" && result.code !== 0) {
            verdict = { status: "suite-error", failed: [], detail: `vitest exited ${result.code} with every test passing (unhandled error — see ${path.basename(result.logPath)})` };
          }
          verdicts[entry.id] = verdict;
        }
        verdictRuns.push({ iteration, verdicts });
        const failed = failedFiles(result.report, packageDir);
        runsByPackage[packageName].push({ label, code: result.code, durationS: result.durationS, loadBefore: result.loadBefore, loadAfter: result.loadAfter, attempts: result.attempts, failedFiles: failed, log: result.logPath });
        const red = Object.entries(verdicts).filter(([, verdict]) => verdict.status !== "pass").map(([id, verdict]) => `${id} (${verdict.status})`);
        say(`${label}: ${result.durationS}s, exit ${result.code}, load ${result.loadBefore}→${result.loadAfter}; named red: ${red.join(", ") || "none"}; other red files: ${failed.filter((file) => !step.entries.some((entry) => entry.file === file.file)).map((file) => file.file).join(", ") || "none"}`);
        writeSummaries(false);
      }
    }
  }
  stopBurners();
  const { gate } = writeSummaries(true);
  console.log("");
  console.log(readFileSync(path.join(outDir, "summary.md"), "utf8"));
  say(`summary: ${path.join(outDir, "summary.md")}`);
  process.exit(infraFailure ? 2 : gate ? 0 : 1);
}

main().catch((error) => {
  stopBurners();
  console.error(error);
  process.exit(2);
});
