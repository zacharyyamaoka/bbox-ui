// scripts/flake/tally.mjs — the pure half of G-FLAKE's repeat harness.
//
// Reads one vitest JSON report (the Jest-compatible shape vitest's `json`
// reporter writes: testResults[].name is the absolute file path,
// testResults[].assertionResults[].title is the test / story name) and
// decides, for every manifest entry, whether THIS run is a pass.
//
// WHY a pass has to be earned, not defaulted: a de-flake lane is exactly the
// place where a test can be made "green" by making it stop testing. So an
// entry whose file or named test is missing from the report is UNMATCHED
// (red), a skipped/todo test is SKIPPED (red), and a file that failed to
// load or threw outside a test is a SUITE ERROR (red). Only a run in which
// every matched test reported `passed` counts toward 10/10.
//
// No dependencies; `repeat.mjs` imports it and `tally.test.mjs` pins it
// (`node --test scripts/flake/tally.test.mjs`).

import path from "node:path";

/** @typedef {{ id: string, package: string, file: string, tests?: string[], followUp?: string }} Entry */

/**
 * The report's file result for `entry.file` (package-relative), or null.
 * Matched on the path suffix so the report's absolute paths (which differ
 * per worktree) never matter.
 */
export function fileResultFor(report, packageDir, entryFile) {
  const want = path.resolve(packageDir, entryFile);
  const results = Array.isArray(report?.testResults) ? report.testResults : [];
  return (
    results.find((result) => path.resolve(result.name) === want) ??
    results.find((result) => typeof result.name === "string" && result.name.endsWith(`/${entryFile}`)) ??
    null
  );
}

/**
 * One entry's verdict for one run.
 * @returns {{ status: "pass" | "fail" | "unmatched" | "skipped" | "suite-error", failed: string[], detail: string }}
 */
export function judgeEntry(report, packageDir, entry) {
  const file = fileResultFor(report, packageDir, entry.file);
  if (!file) {
    return { status: "unmatched", failed: [], detail: `no result for ${entry.file} in the report` };
  }
  const assertions = Array.isArray(file.assertionResults) ? file.assertionResults : [];
  const matched = entry.tests?.length
    ? assertions.filter((assertion) => entry.tests.includes(assertion.title) || entry.tests.includes(assertion.fullName))
    : assertions;

  if (entry.tests?.length) {
    const seen = new Set(matched.flatMap((assertion) => [assertion.title, assertion.fullName]));
    const missing = entry.tests.filter((title) => !seen.has(title));
    if (missing.length) {
      return { status: "unmatched", failed: [], detail: `named test(s) not in the report: ${missing.join(" | ")}` };
    }
  }
  if (matched.length === 0) {
    // A file that reported no tests at all is a load failure (or an emptied file), never a pass.
    const message = firstLine(file.message);
    return { status: file.status === "failed" ? "suite-error" : "unmatched", failed: [], detail: message || `${entry.file} reported no tests` };
  }

  const failed = matched.filter((assertion) => assertion.status === "failed");
  if (failed.length) {
    return {
      status: "fail",
      failed: failed.map((assertion) => assertion.title),
      detail: failed.map((assertion) => `${assertion.title}: ${firstLine((assertion.failureMessages ?? [])[0])}`).join(" ; "),
    };
  }
  const notRun = matched.filter((assertion) => assertion.status !== "passed");
  if (notRun.length) {
    return { status: "skipped", failed: notRun.map((assertion) => assertion.title), detail: `not run (${notRun.map((assertion) => `${assertion.title}: ${assertion.status}`).join(" ; ")})` };
  }
  // Every matched test passed, but the FILE can still have failed outside
  // them (an afterAll that threw, an error vitest pinned to the file). That
  // is a file-level error — vitest's JSON reporter puts it in `message`
  // (file.result.errors[0].message) — or a "failed" file none of whose tests
  // failed. Whole-file and per-test entries both count it. What does NOT
  // count against a per-test entry is ANOTHER test in the same file failing:
  // menus.smoke.test.tsx carries EXPECTED_RED tests owned by other lanes.
  if (fileLevelError(file)) {
    return { status: "suite-error", failed: [], detail: firstLine(file.message) || `${entry.file} failed outside its tests` };
  }
  return { status: "pass", failed: [], detail: "" };
}

/** A failure of the file itself, as opposed to one of its tests failing. */
export function fileLevelError(file) {
  if (file.message && String(file.message).trim()) return true;
  const assertions = Array.isArray(file.assertionResults) ? file.assertionResults : [];
  return file.status === "failed" && !assertions.some((assertion) => assertion.status === "failed");
}

/** Every file in the report that failed, package-relative — used to surface flakes nobody named yet. */
export function failedFiles(report, packageDir) {
  const results = Array.isArray(report?.testResults) ? report.testResults : [];
  return results
    .filter((result) => result.status === "failed" || (result.assertionResults ?? []).some((assertion) => assertion.status === "failed"))
    .map((result) => ({
      file: path.relative(packageDir, result.name),
      failed: (result.assertionResults ?? []).filter((assertion) => assertion.status === "failed").map((assertion) => assertion.title),
      message: firstLine(result.message),
    }));
}

/** The package-relative files of a report, in the order they started (earliest test start). */
export function fileOrder(report, packageDir) {
  const results = Array.isArray(report?.testResults) ? report.testResults : [];
  return [...results].sort((a, b) => (a.startTime ?? 0) - (b.startTime ?? 0)).map((result) => path.relative(packageDir, result.name));
}

/** True when a report carries real results (as opposed to a run that never started, e.g. the browser port was taken). */
export function reportHasResults(report) {
  return Boolean(report && Array.isArray(report.testResults) && report.testResults.length > 0 && (report.numTotalTests ?? 0) > 0);
}

/**
 * Fold per-run verdicts into per-entry totals.
 * @param {Entry[]} entries
 * @param {Array<{ iteration: number, verdicts: Record<string, { status: string, detail: string }> }>} runs
 */
export function summarise(entries, runs) {
  return entries.map((entry) => {
    const samples = runs.filter((run) => run.verdicts[entry.id]);
    const passes = samples.filter((run) => run.verdicts[entry.id].status === "pass").length;
    const failures = samples
      .filter((run) => run.verdicts[entry.id].status !== "pass")
      .map((run) => ({ iteration: run.iteration, status: run.verdicts[entry.id].status, detail: run.verdicts[entry.id].detail }));
    return { id: entry.id, file: entry.file, tests: entry.tests ?? [], followUp: entry.followUp ?? "", samples: samples.length, passes, failures };
  });
}

/** The gate: every gated (non-follow-up) entry passed every one of `repeat` samples. */
export function gatePasses(totals, repeat) {
  return totals.filter((total) => !total.followUp).every((total) => total.samples === repeat && total.passes === repeat);
}

export function firstLine(text) {
  if (!text) return "";
  // eslint-disable-next-line no-control-regex
  const clean = String(text).replace(/\x1b\[[0-9;]*m/g, "");
  const line = clean.split("\n").find((candidate) => candidate.trim().length > 0) ?? "";
  return line.trim().slice(0, 220);
}
