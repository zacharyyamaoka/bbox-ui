// scripts/flake/tally.test.mjs — pins the verdict rules the G-FLAKE gate
// rests on. Run: node --test scripts/flake/tally.test.mjs
//
// WHY these cases: the gate is only worth anything if it cannot be satisfied
// by making a flaky test stop testing. Each case below is one way a de-flake
// could "pass" without passing: rename the story, skip it, empty the file,
// throw outside the test, or pass every test while the file still errors.

import assert from "node:assert/strict";
import { test } from "node:test";

import { failedFiles, fileOrder, gatePasses, judgeEntry, reportHasResults, summarise } from "./tally.mjs";

const PKG = "/repo/apps/storybook-basics";

function report(files) {
  return {
    numTotalTests: files.reduce((count, file) => count + file.assertionResults.length, 0),
    testResults: files.map((file) => ({ status: "passed", message: "", ...file, name: `${PKG}/${file.name}` })),
  };
}

const passing = (title) => ({ title, fullName: title, status: "passed", failureMessages: [] });
const failing = (title, message) => ({ title, fullName: title, status: "failed", failureMessages: [message] });

test("a whole-file entry passes only when every test in the file passed", () => {
  const entry = { id: "E", package: "sb", file: "src/a.stories.tsx" };
  assert.equal(judgeEntry(report([{ name: "src/a.stories.tsx", assertionResults: [passing("One"), passing("Two")] }]), PKG, entry).status, "pass");
  const red = judgeEntry(report([{ name: "src/a.stories.tsx", status: "failed", assertionResults: [passing("One"), failing("Two", "Error: expected 1 to be 2\n  at x")] }]), PKG, entry);
  assert.equal(red.status, "fail");
  assert.deepEqual(red.failed, ["Two"]);
  assert.match(red.detail, /Two: Error: expected 1 to be 2$/);
});

test("a file missing from the report is UNMATCHED, never a pass", () => {
  const entry = { id: "E", package: "sb", file: "src/gone.stories.tsx" };
  assert.equal(judgeEntry(report([{ name: "src/a.stories.tsx", assertionResults: [passing("One")] }]), PKG, entry).status, "unmatched");
});

test("a renamed test is UNMATCHED for a per-test entry", () => {
  const entry = { id: "E", package: "sb", file: "src/a.stories.tsx", tests: ["Callbacks Carry The Row Id"] };
  const verdict = judgeEntry(report([{ name: "src/a.stories.tsx", assertionResults: [passing("Callbacks Carry The Id")] }]), PKG, entry);
  assert.equal(verdict.status, "unmatched");
  assert.match(verdict.detail, /Callbacks Carry The Row Id/);
});

test("a per-test entry ignores other tests' failures in the same file", () => {
  const entry = { id: "E", package: "sb", file: "src/menus.smoke.test.tsx", tests: ["undo"] };
  // The file is "failed" because of ANOTHER lane's test (menus.smoke's EXPECTED_RED
  // burger order); the entry's own test passed and the file has no error of its own.
  const verdict = judgeEntry(report([{ name: "src/menus.smoke.test.tsx", status: "failed", assertionResults: [passing("undo"), failing("burger order", "AssertionError")] }]), PKG, entry);
  assert.equal(verdict.status, "pass");
  // ...but the same entry is red when ITS test fails.
  const red = judgeEntry(report([{ name: "src/menus.smoke.test.tsx", status: "failed", assertionResults: [failing("undo", "Error: waitFor timed out"), failing("burger order", "AssertionError")] }]), PKG, entry);
  assert.equal(red.status, "fail");
  assert.deepEqual(red.failed, ["undo"]);
});

test("a per-test entry passes when its test passed and the file carries no error of its own", () => {
  const entry = { id: "E", package: "sb", file: "src/menus.smoke.test.tsx", tests: ["undo"] };
  const file = { name: "src/menus.smoke.test.tsx", status: "passed", assertionResults: [passing("undo"), passing("burger order")] };
  assert.equal(judgeEntry(report([file]), PKG, entry).status, "pass");
});

test("a skipped or todo test is SKIPPED, never a pass", () => {
  const entry = { id: "E", package: "sb", file: "src/a.stories.tsx" };
  const verdict = judgeEntry(report([{ name: "src/a.stories.tsx", assertionResults: [passing("One"), { title: "Two", fullName: "Two", status: "skipped" }] }]), PKG, entry);
  assert.equal(verdict.status, "skipped");
});

test("a file that reported no tests is a suite error (it failed to load) or unmatched (it is empty)", () => {
  const entry = { id: "E", package: "sb", file: "src/a.stories.tsx" };
  assert.equal(judgeEntry(report([{ name: "src/a.stories.tsx", status: "failed", message: "SyntaxError: nope", assertionResults: [] }, { name: "src/b.stories.tsx", assertionResults: [passing("x")] }]), PKG, entry).status, "suite-error");
  assert.equal(judgeEntry(report([{ name: "src/a.stories.tsx", status: "passed", assertionResults: [] }, { name: "src/b.stories.tsx", assertionResults: [passing("x")] }]), PKG, entry).status, "unmatched");
});

test("every test passed but the file errored outside them: a suite error", () => {
  const entry = { id: "E", package: "sb", file: "src/a.stories.tsx" };
  const verdict = judgeEntry(report([{ name: "src/a.stories.tsx", status: "failed", message: "Error: afterAll hook timed out", assertionResults: [passing("One")] }]), PKG, entry);
  assert.equal(verdict.status, "suite-error");
  assert.match(verdict.detail, /afterAll/);
});

test("a run that never started has no results (the harness retries it instead of counting it)", () => {
  assert.equal(reportHasResults(null), false);
  assert.equal(reportHasResults({ numTotalTests: 0, testResults: [] }), false);
  assert.equal(reportHasResults(report([{ name: "src/a.stories.tsx", assertionResults: [passing("One")] }])), true);
});

test("failedFiles surfaces every red file, named or not", () => {
  const files = failedFiles(report([{ name: "src/a.stories.tsx", status: "failed", assertionResults: [failing("Two", "x")] }, { name: "src/b.stories.tsx", assertionResults: [passing("x")] }]), PKG);
  assert.deepEqual(files.map((file) => file.file), ["src/a.stories.tsx"]);
});

test("the gate needs every gated entry at N/N samples; follow-ups are measured, not gated", () => {
  const entries = [{ id: "A", file: "a" }, { id: "B", file: "b", followUp: "outside the write set" }];
  const run = (iteration, a, b) => ({ iteration, verdicts: { A: { status: a, detail: "" }, B: { status: b, detail: "" } } });
  assert.equal(gatePasses(summarise(entries, [run(1, "pass", "fail"), run(2, "pass", "fail")]), 2), true);
  assert.equal(gatePasses(summarise(entries, [run(1, "pass", "pass"), run(2, "fail", "pass")]), 2), false);
  // Fewer samples than asked for (a run lost to the harness) is not a pass.
  assert.equal(gatePasses(summarise(entries, [run(1, "pass", "pass")]), 2), false);
});

test("fileOrder reads the order files really ran in, so an order repro can refuse a run that did not follow it", () => {
  const ran = report([
    { name: "src/app.smoke.test.tsx", startTime: 200, assertionResults: [passing("x")] },
    { name: "src/region.smoke.test.tsx", startTime: 100, assertionResults: [passing("y")] },
  ]);
  assert.deepEqual(fileOrder(ran, PKG), ["src/region.smoke.test.tsx", "src/app.smoke.test.tsx"]);
});
